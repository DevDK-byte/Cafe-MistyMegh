public class login_main
{
	public static void main(String[] args)
	{
		Login l = new Login();
	}
}